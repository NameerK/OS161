#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <addrspace.h>

int sys_fork(struct trapframe *tf, int *retval) {
    /*sys_fork prepares a thread_fork that starts at md_forkentry*/
    struct trapframe *child_tf;
    struct addrspace *child_as;
    struct thread *child_thread;
    int result;

    // Create a new trapframe for the child
    child_tf = kmalloc(sizeof(struct trapframe));
    if (child_tf == NULL) {
        return ENOMEM;
    }

    // Copy the parent's address space into the child's address space
    child_as = kmalloc(sizeof(struct addrspace));
    if (child_as == NULL) {
        return ENOMEM;
    }
    result = as_copy(curthread->t_vmspace, &child_as);
    if (result) {
        return result;
    }

    // Copy the parent's trapframe into the child's trapframe
    *child_tf = *tf;

    // Call thread_fork to start the child at md_forkentry
    result = thread_fork("child", child_tf, (unsigned long)child_as, (void (*)(void *, unsigned long))md_forkentry, &child_thread);

    // If thread_fork fails, return the error code
    if (result) {
        return result;
    }

    // Set retval to the child's pid
    *retval = child_thread->pid;

    // Return
    return 0;
}