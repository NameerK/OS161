#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <synch.h>

int sys_exit(int code){
    curthread->exit_code = code;
    curthread->exited = 1;
    lock_release(curthread->exit_lock);
    thread_exit();
    return 0;
}
