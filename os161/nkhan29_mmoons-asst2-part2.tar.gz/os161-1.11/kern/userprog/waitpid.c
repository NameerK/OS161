#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <synch.h>

int sys_waitpid(pid_t pid, int *status, int options, int *retval) {
    if (status == NULL)
    {
        return EFAULT;
    }
    if (options != 0)
    {
        return EINVAL;
    }
    struct thread *child = NULL;
    child = pid_lookup(pid);
    if (child == NULL)
    {
        return EFAULT;
    }
    
    if (child->exited == 0)
    {
        lock_acquire(child->exit_lock);
        *status = child->exit_code;
        *retval = pid;
        if (lock_do_i_hold(child->wait_lock))
            lock_release(child->wait_lock);
        lock_release(child->exit_lock);
    }
    else
    {
        *status = child->exit_code;
        *retval = pid;
        if (lock_do_i_hold(child->wait_lock))
            lock_release(child->wait_lock);
    }
    
    return 0;
}