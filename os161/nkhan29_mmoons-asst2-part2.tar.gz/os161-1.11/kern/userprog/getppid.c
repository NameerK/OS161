#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>

int sys_getppid(int *retval) {
    *retval = curthread->ppid;
    if (*retval == -1)
    {
        return EFAULT;
    }
    
    return 0;
}