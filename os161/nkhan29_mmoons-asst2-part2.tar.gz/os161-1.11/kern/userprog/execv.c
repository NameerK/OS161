#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <addrspace.h>
#include <vfs.h>

#define O_RDONLY 0

/* Replace the currently executing program image with a new process image
 * Process id is unchanged
 * int sys_execv(char *program, char **args)
 * program: path name of the program to run
 * Args: tf->tf_a0 and tf->tf_a1. It’s an array of pointers, each pointer points to a user space
 * string.
 * 
 * execv does more or less the same thing with runprogram. The overall flow of
 * sys_execv are:
 *  Copy arguments from user space into kernel buffer
 *  Open the executable, create a new address space and load the elf into it
 *  Copy the arguments from kernel buffer into user stack
 *  Allocate a stack on the new address space using as_define_stack()
 *  Return to user mode by calling md_usermode
 */
int sys_execv(const char *program, char **args) {
    struct vnode *v;
    vaddr_t entrypoint, stackptr;
    int result;
    int argc = 0;
    int i = 0;
    size_t actual;
    size_t len;
    char **kbuf;
    char *kbuf2;
    int spl;

    spl = splhigh();
    // Copy arguments from user space into kernel buffer
    // not complete
    while (args[argc] != NULL) {
        argc++;
    }
    kbuf = kmalloc(sizeof(char *) * (argc + 1));
    if (kbuf == NULL) {
        return ENOMEM;
    }
    while (i < argc) {
        len = strlen(args[i]) + 1;
        kbuf2 = kmalloc(sizeof(char) * len);
        if (kbuf2 == NULL) {
            return ENOMEM;
        }
        result = copyinstr((const_userptr_t)args[i], kbuf2, len, &actual);
        if (result) {
            return result;
        }
        kbuf[i] = kbuf2;
        i++;
    }
    kbuf[argc] = NULL;

    // Open the executable, create a new address space and load the elf into it
    result = vfs_open((char *)program, O_RDONLY, &v);
    if (result) {
        return result;
    }
    curthread->t_vmspace = as_create();
    if (curthread->t_vmspace == NULL) {
        vfs_close(v);
        return ENOMEM;
    }
    as_activate(curthread->t_vmspace);
    result = load_elf(v, &entrypoint);
    if (result) {
        vfs_close(v);
        return result;
    }
    vfs_close(v);

    // Copy the arguments from kernel buffer into user stack
    result = as_define_stack(curthread->t_vmspace, &stackptr);
    if (result) {
        return result;
    }
    stackptr -= sizeof(char *) * (argc + 1);
    result = copyout(kbuf, (userptr_t)stackptr, sizeof(char *) * (argc + 1));
    if (result) {
        return result;
    }
    i = 0;
    while (i < argc) {
        len = strlen(kbuf[i]) + 1;
        stackptr -= len;
        result = copyoutstr(kbuf[i], (userptr_t)stackptr, len, &actual);
        if (result) {
            return result;
        }
        kfree(kbuf[i]);
        i++;
    }
    kfree(kbuf);

    splx(spl);
    
    // Return to user mode by calling md_usermode
    md_usermode(argc, (userptr_t)stackptr, stackptr, entrypoint);

    panic("md_usermode returned\n");
    return EINVAL;
}