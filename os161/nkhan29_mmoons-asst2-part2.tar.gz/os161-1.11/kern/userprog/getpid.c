#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <curthread.h>
#include <thread.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>

int sys_getpid(int *retval) {
    *retval = curthread->pid;
    return 0;  
}