/*
 * fsync
 */

#include "test.h"

void
test_fsync(void)
{
	test_fsync_fd();
}

