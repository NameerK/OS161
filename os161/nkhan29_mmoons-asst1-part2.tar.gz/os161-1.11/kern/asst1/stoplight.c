/* 
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 * 
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h>


/*
 *
 * Constants
 *
 */

//locks representing the 3 sections of the intersection AB, BC, CA
static struct lock *lockAB;
static struct lock *lockBC;
static struct lock *lockCA;


//locks representing the 3 routes to the intersection
static struct lock *lockA;
static struct lock *lockB;
static struct lock *lockC;

//locks for controlling the amount of cars waiting to enter the intersection
static struct lock *lockACarsWaiting;
static struct lock *lockBCarsWaiting;
static struct lock *lockCCarsWaiting;

//locks for trucks waiting to enter the route
static struct lock *lockATruckWaiting;
static struct lock *lockBTruckWaiting;
static struct lock *lockCTruckWaiting;

//lock for cars that have left the intersection
static struct lock *lockCarsPassed;

//lock for print statements to prevent overlapping
static struct lock *lockPrint;

//cars amount waiting to enter the intersection
static int carsWaitingA = 0;
static int carsWaitingB = 0;
static int carsWaitingC = 0;

//number of vehicles that have passed the int.,.ersection
static int carsPassed = 0;

//char array for printing
static const char *route[3] = {"A", "B", "C"};
static const char *intersection[3] = {"AB", "BC", "CA"};
static const char *type[2] = {"Car", "Truck"};

//the address the CPU will be sleeping on until all vehicles have left the intersection
static void *CPUSleepAddress = &CPUSleepAddress;

//the adresses the Trucks will be sleeping on until there are no more cars waiting to enter that route
static void *TruckASleepAddress = &TruckASleepAddress;
static void *TruckBSleepAddress = &TruckBSleepAddress;
static void *TruckCSleepAddress = &TruckCSleepAddress;

//the adresses the vehicles turning left will be sleeping on until there are less than 2 vheicles trying to turn left to avoid deadlock
static struct lock *lockLeftTurners;

//the number of vehicles trying to turn left
static int leftTurners = 0;
static struct lock *lockLeftTurnersAmount;



/*
 * Number of vehicles created.
 */

#define NVEHICLES 20


/*
 *
 * Function Definitions
 *
 */

/* turnPrint()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *      unsigned long vehicletype: the type of vehicle (car or truck)
 * 		unsigned long turn: the turn type the vehicle is making (left or right)
 *  	unsigned long turnState: the state of the turn (entering, exiting, or waiting)
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function prints the turn that the vehicle is making.
 */
static
void
turnPrint(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype,
		unsigned long turnDirection,
		unsigned long turnState,
		unsigned long intersectionState)
{

	//lock_acquire(lockPrint);
	switch(turnDirection)
	{

		case 0://left turn
			switch (turnState)
			{
				case 0://entering the Route
					kprintf("%s %lu entered Route %s and is waiting for %s.\n\n", 
					type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState]);
					
					break;
				case 1://waiting for next intersection
					kprintf("%s %lu from Route %s is entering %s and is waiting for %s.\n\t\t\t\t\t\t\t\t %s is used Route %s is free\n",
					type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState], intersection[(intersectionState+1)%3], intersection[intersectionState], route[vehicledirection]);
					
					break;
				case 2://entering the next intersection
					kprintf("%s %lu from Route %s has exit %s and entered %s.\n\t\t\t\t\t\t\t\t %s is free and %s is used\n", 
					type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState], intersection[(intersectionState+1)%3], intersection[intersectionState], intersection[(intersectionState+1)%3]);
					
					break;
				case 3://exiting
					kprintf("%s %lu from Route %s has exit %s and entered Route %s.\n\t\t\t\t\t\t\t\t %s is free\n", 
					type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState], route[(vehicledirection+2)%3], intersection[intersectionState]);
					
					lock_acquire(lockCarsPassed);
					carsPassed++;
					lock_release(lockCarsPassed);
					break;
				}
				break;

			case 1://right turn
				switch (turnState)
				{
					case 0://entering the Route
						kprintf("%s %lu entered Route %s and is waiting for %s.\n\n", 
						type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState]);
						
						break;
					case 1://entering the intersection
						kprintf("%s %lu from Route %s is entering %s.\n\t\t\t\t\t\t\t\t %s is used and Route %s is free\n", 
						type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState], intersection[intersectionState], route[vehicledirection]);
						
						break;
					case 2://exiting
						kprintf("%s %lu from Route %s has exit %s and entered Route %s.\n\t\t\t\t\t\t\t\t %s is free\n", 
						type[vehicletype], vehiclenumber, route[vehicledirection], intersection[intersectionState], route[(vehicledirection+1)%3], intersection[intersectionState]);
						
						lock_acquire(lockCarsPassed);
						carsPassed++;
						lock_release(lockCarsPassed);
						break;
				}
				break;
	}
	
	if(NVEHICLES <= carsPassed)
	{
		kprintf("All vehicles have left the intersection.\n");
		int spl = splhigh();
		thread_wakeup(CPUSleepAddress);
		splx(spl);
	}

	//lock_release(lockPrint);
}



/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	lock_acquire(lockLeftTurnersAmount);
	leftTurners++;
	lock_release(lockLeftTurnersAmount);

	//left turn sleep if there are 2 or more left turns
	while(leftTurners >= 2)
	{
		lock_acquire(lockLeftTurnersAmount);
		leftTurners--;
		lock_release(lockLeftTurnersAmount);

		lock_acquire(lockLeftTurners);
		
		lock_acquire(lockLeftTurnersAmount);
		leftTurners++;
		lock_release(lockLeftTurnersAmount);
	}

	switch(vehicledirection)
	{
		case 0://approaching from Route A
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 0, 0);//entering Route A and waiting for AB
			lock_acquire(lockAB);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 1, 0);//entering AB and waiting for BC
			lock_release(lockA);//left the route
			lock_release(lockATruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockACarsWaiting);
				carsWaitingA--;
				lock_release(lockACarsWaiting);
			}

			lock_acquire(lockBC);
			lock_release(lockAB);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 2, 0);//exiting AB and entering BC
			lock_release(lockBC);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 3, 1);//exiting BC and entering Route C
			break;
		case 1://approaching from Route B
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 0, 1);//entering Route B and waiting for BC
			lock_acquire(lockBC);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 1, 1);//entering BC and waiting for CA
			lock_release(lockB);//left the route
			lock_release(lockBTruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockBCarsWaiting);
				carsWaitingB--;
				lock_release(lockBCarsWaiting);
			}

			lock_acquire(lockCA);
			lock_release(lockBC);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 2, 1);//exiting BC and entering CA
			lock_release(lockCA);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 3, 2);//exiting CA and entering Route A
			break;
		case 2://approaching from Route C
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 0, 2);//entering Route C and waiting for CA
			lock_acquire(lockCA);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 1, 2);//entering CA and waiting for AB
			lock_release(lockC);//left the route
			lock_release(lockCTruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockCCarsWaiting);
				carsWaitingC--;
				lock_release(lockCCarsWaiting);
			}

			lock_acquire(lockAB);
			lock_release(lockCA);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 2, 2);//exiting CA and entering AB
			lock_release(lockAB);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 0, 3, 0);//exiting AB and entering Route B
			break;
	}
	
	lock_acquire(lockLeftTurnersAmount);
	leftTurners--;
	lock_release(lockLeftTurnersAmount);

	lock_release(lockLeftTurners);
}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	switch (vehicledirection)
	{
		case 0://approaching from Route A
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 0, 0);//entering Route A and waiting for AB
			lock_acquire(lockAB);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 1, 0);//entering AB
			lock_release(lockA);//left the route
			lock_release(lockATruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockACarsWaiting);
				carsWaitingA--;
				lock_release(lockACarsWaiting);
			}

			lock_release(lockAB);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 2, 0);//exiting AB and entering Route B
			break;
		case 1://approaching from Route B
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 0, 1);//entering Route B and waiting for BC
			lock_acquire(lockBC);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 1, 1);//entering BC
			lock_release(lockB);//left the route
			lock_release(lockBTruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockBCarsWaiting);
				carsWaitingB--;
				lock_release(lockBCarsWaiting);
			}

			lock_release(lockBC);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 2, 1);//exiting BC and entering Route C
			break;
		case 2://approaching from Route C
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 0, 2);//entering Route C and waiting for CA
			lock_acquire(lockCA);

			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 1, 2);//entering CA
			lock_release(lockC);//left the route
			lock_release(lockCTruckWaiting);//reevaluate truck waiting

			if(vehicletype == 0)//remove car from waiting list
			{
				lock_acquire(lockCCarsWaiting);
				carsWaitingC--;
				lock_release(lockCCarsWaiting);
			}

			lock_release(lockCA);
			turnPrint(vehicledirection, vehiclenumber, vehicletype, 1, 2, 2);//exiting CA and entering Route A
			break;
	}
}


/*
 * approachintersection()
 *
 * Arguments: 
 *      void * unusedpointer: currently unused.
 *      unsigned long vehiclenumber: holds vehicle id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createvehicles().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */

static
void
approachintersection(void * unusedpointer,
		unsigned long vehiclenumber)
{
	int vehicledirection, turndirection, vehicletype;

	/*
	 * Avoid unused variable and function warnings.
	 */

	(void) unusedpointer;
	//(void) vehiclenumber;
	//(void) turnleft;
	//(void) turnright;

	/*
	 * vehicledirection is set randomly.
	 */

	vehicledirection = random() % 3;
	//the directions are 0, 1, 2 for intersection A, B, C respectively
	turndirection = random() % 2;
	//the turn directions are 0, 1 for left and right respectively
	vehicletype = random() % 2;
	//the vehicle types are 0, 1 for car and truck respectively


	//print the vehicle's info that wants to enter the route to the intersection
	lock_acquire(lockPrint);
	kprintf("%s %lu wants to enter route %s.\n\n", type[vehicletype], vehiclenumber, route[vehicledirection]);
	lock_release(lockPrint);

	//increment the number of cars waiting to enter the route
	if(vehicletype == 0){
		switch (vehicledirection)
		{
			case 0:
				lock_acquire(lockACarsWaiting);
				carsWaitingA++;
				lock_release(lockACarsWaiting);
				break;
			case 1:
				lock_acquire(lockBCarsWaiting);
				carsWaitingB++;
				lock_release(lockBCarsWaiting);
				break;
			case 2:
				lock_acquire(lockCCarsWaiting);
				carsWaitingC++;
				lock_release(lockCCarsWaiting);
				break;
		}
	}

	//trucks have to sleep until the route is free of cars
	if(vehicletype == 1){
		switch (vehicledirection)
		{
			case 0:
				while (carsWaitingA != 0)
				{
					lock_acquire(lockATruckWaiting);
					lock_release(lockATruckWaiting);
					int spl = splhigh();
					thread_yield();
					splx(spl);
				}
				break;
			case 1:
				while (carsWaitingB != 0)
				{
					lock_acquire(lockBTruckWaiting);
					lock_release(lockBTruckWaiting);
					int spl = splhigh();
					thread_yield();
					splx(spl);
				}
				break;
			case 2:
				while (carsWaitingC != 0)
				{
					lock_acquire(lockCTruckWaiting);
					lock_release(lockCTruckWaiting);
					int spl = splhigh();
					thread_yield();
					splx(spl);
				}
				break;
		}
	}

	//lock the route to the intersection
	switch (vehicledirection)
	{
		case 0:
			lock_acquire(lockA);
			lock_acquire(lockATruckWaiting);
			break;
		case 1:
			lock_acquire(lockB);
			lock_acquire(lockBTruckWaiting);
			break;
		case 2:
			lock_acquire(lockC);
			lock_acquire(lockCTruckWaiting);
			break;
	}

	//print the vehicle's info that has entered the route to the intersection
	//turnPrint(vehicledirection, vehiclenumber, vehicletype, turndirection, 0, vehicledirection);

	//send the vehicle to the intersection with the appropriate turn
	switch(turndirection){
		case 0:
			turnleft(vehicledirection, vehiclenumber, vehicletype);
			break;
		case 1:
			turnright(vehicledirection, vehiclenumber, vehicletype);
			break;
	}


}


/*
 * createvehicles()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createvehicles(int nargs,
		char ** args)
{
	int index, error;

	/*
	 * Avoid unused variable warnings.
	 */

	(void) nargs;
	(void) args;


	//set int variables to 0
	carsWaitingA = 0;
	carsWaitingB = 0;
	carsWaitingC = 0;
	carsPassed = 0;

	//initialize the locks
	lockAB = lock_create("lockAB");
	lockBC = lock_create("lockBC");
	lockCA = lock_create("lockCA");
	
	lockA = lock_create("lockA");
	lockB = lock_create("lockB");
	lockC = lock_create("lockC");
	
	lockATruckWaiting = lock_create("lockATruckWaiting");
	lockBTruckWaiting = lock_create("lockBTruckWaiting");
	lockCTruckWaiting = lock_create("lockCTruckWaiting");
	
	lockACarsWaiting = lock_create("lockACarsWaiting");
	lockBCarsWaiting = lock_create("lockBCarsWaiting");
	lockCCarsWaiting = lock_create("lockCCarsWaiting");

	lockCarsPassed = lock_create("lockCarsPassed");
	
	lockLeftTurners = lock_create("lockLeftTurners");
	lockLeftTurnersAmount = lock_create("lockLeftTurnersAmount");

	lockPrint = lock_create("lockPrint");

	/*
	 * Start NVEHICLES approachintersection() threads.
	 */

	for (index = 0; index < NVEHICLES; index++) {

		error = thread_fork("approachintersection thread",
				NULL,
				index,
				approachintersection,
				NULL
				);

		/*
		 * panic() on error.
		 */

		if (error) {

			panic("approachintersection: thread_fork failed: %s\n",
					strerror(error)
				 );
		}
	}
	


	if (NVEHICLES >= carsPassed){
		int spl = splhigh();
		thread_sleep(CPUSleepAddress);
		splx(spl);
	}

	//destroy the locks
	lock_destroy(lockAB);
	lock_destroy(lockBC);
	lock_destroy(lockCA);

	lock_destroy(lockA);
	lock_destroy(lockB);
	lock_destroy(lockC);
	
	lock_destroy(lockATruckWaiting);
	lock_destroy(lockBTruckWaiting);
	lock_destroy(lockCTruckWaiting);
	
	lock_destroy(lockACarsWaiting);
	lock_destroy(lockBCarsWaiting);
	lock_destroy(lockCCarsWaiting);
	
	lock_destroy(lockLeftTurners);
	lock_destroy(lockPrint);

	return 0;
}
